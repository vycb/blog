
module.exports = require('./lib/ejs');